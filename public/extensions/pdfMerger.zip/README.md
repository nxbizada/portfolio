# PDF Merger Chrome Extension

A Chrome extension that allows you to merge multiple PDF files, view, and organize their pages before downloading the merged document.

## Features

- Upload multiple PDF files through the extension popup
- View thumbnails of all PDF pages
- Drag and drop interface for reordering pages
- Remove individual pages if needed
- Merge PDFs and download the combined document

## Installation

1. Clone or download this repository to your local machine.
2. Open Chrome and go to `chrome://extensions/`.
3. Enable "Developer mode" by toggling the switch in the top right corner.
4. Click "Load unpacked" and select the folder containing this extension.
5. The PDF Merger extension should now appear in your Chrome toolbar.

## Usage

1. Click on the PDF Merger extension icon in your Chrome toolbar.
2. Click "Choose PDF Files" and select one or more PDF files you want to merge.
3. Click "Open PDF Manager" to open the page organizer.
4. On the manager page, you can:
   - View thumbnails of all pages
   - Drag and drop pages to reorder them
   - Remove unwanted pages by clicking the "×" button
   - Add more PDFs by clicking "Add More PDFs"
5. When you're satisfied with the arrangement, click "Merge & Download" to generate and download the merged PDF.

## Dependencies

This extension uses the following libraries:
- [PDF.js](https://mozilla.github.io/pdf.js/) for rendering PDF previews
- [pdf-lib](https://pdf-lib.js.org/) for PDF manipulation and merging
- [SortableJS](https://sortablejs.github.io/Sortable/) for drag-and-drop reordering

## Notes

- All PDF processing happens locally in your browser; no files are uploaded to any server.
- For large PDF files, the merging process might take a few moments to complete.

## License

MIT 