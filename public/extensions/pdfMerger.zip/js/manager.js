// Set PDF.js worker path immediately when script loads
if (typeof pdfjsLib !== 'undefined') {
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
  console.log('PDF.js worker URL set to:', pdfjsLib.GlobalWorkerOptions.workerSrc);
}

document.addEventListener('DOMContentLoaded', function() {
  const pdfPagesContainer = document.getElementById('pdf-pages');
  const addMoreBtn = document.getElementById('add-more');
  const mergeDownloadBtn = document.getElementById('merge-download');
  const addPdfInput = document.getElementById('add-pdf-input');
  
  // Store rendered pages/documents in memory
  let pdfPages = [];
  let pdfDocuments = [];
  
  console.log('Manager page loaded');
  
  // Initialize the application safely
  initializeApp();

  // Main initialization function 
  function initializeApp() {
    console.log('Initializing PDF Manager application');
    
    // Setup PDF.js worker path again to be sure
    if (typeof pdfjsLib !== 'undefined') {
      console.log('Setting PDF.js worker path');
      pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
      console.log('PDF.js worker path set to:', pdfjsLib.GlobalWorkerOptions.workerSrc);
    } else {
      console.error('PDF.js library not loaded yet');
    }
    
    // Check if required libraries are available
    const missingLibraries = checkLibraries();
    if (missingLibraries.length > 0) {
      const errorMsg = `Error: Required libraries not loaded: ${missingLibraries.join(', ')}`;
      console.error(errorMsg);
      console.error('Current global objects:', Object.keys(window).filter(key => 
        key === 'pdfjsLib' || key === 'PDFLib' || key === 'Sortable'));
      showMessage(errorMsg, 'error');
      
      // Retry after a delay in case scripts are still loading
      console.log('Will retry library check in 2 seconds');
      setTimeout(() => {
        console.log('Retrying library check');
        const retryMissing = checkLibraries();
        if (retryMissing.length === 0) {
          console.log('Libraries loaded successfully on retry');
          initializeEvents();
          loadPDFs();
        } else {
          console.error('Libraries still missing after retry:', retryMissing);
          console.error('Script elements:', Array.from(document.querySelectorAll('script')).map(s => s.src));
          showMessage('Error: Required libraries could not be loaded. Please reload the page.', 'error');
        }
      }, 2000);
      return;
    }
    
    // All libraries loaded, proceed
    console.log('All required libraries loaded successfully');
    initializeEvents();
    console.log('Event listeners initialized, will load PDFs in 500ms');
    setTimeout(loadPDFs, 500);
  }

  // Set up event handlers
  function initializeEvents() {
    // Add more PDFs
    addMoreBtn.addEventListener('click', function() {
      console.log('Add more PDFs button clicked');
      addPdfInput.click();
    });
    
    // Handle additional PDF selection
    addPdfInput.addEventListener('change', async function(e) {
      const newFiles = Array.from(e.target.files);
      console.log(`${newFiles.length} new files selected`);
      
      if (newFiles.length > 0) {
        // Show processing message
        showMessage(`Processing new files...`, 'loading');
        
        let successCount = 0;
        // Process files one by one
        for (let i = 0; i < newFiles.length; i++) {
          try {
            const file = newFiles[i];
            showMessage(`Processing file ${i+1}/${newFiles.length}: ${file.name}`, 'loading');
            
            const success = await processNewFile(file);
            if (success) successCount++;
          } catch (error) {
            console.error(`Error processing file ${i+1}:`, error);
          }
        }
        
        if (successCount > 0) {
          // Initialize sortable if it's the first successful file
          if (pdfDocuments.length === successCount) {
            initializeSortable();
          }
          removeMessage();
        } else {
          showMessage('Error adding files. Please try again.', 'error');
        }
      }
    });
    
    // Merge and download PDFs
    mergeDownloadBtn.addEventListener('click', mergePDFsAndDownload);

    // Event listener for "Add More PDFs" button
    document.getElementById('add-more').addEventListener('click', function() {
      console.log('Add More PDFs button clicked');
      
      // First retrieve existing files to keep them
      chrome.storage.local.get('pdfFilesInfo', function(result) {
        let existingFiles = [];
        let timestamp = Date.now();
        
        if (result.pdfFilesInfo && result.pdfFilesInfo.files) {
          // Filter out any potential duplicates in existing files
          const uniqueFiles = new Map();
          result.pdfFilesInfo.files.forEach(file => {
            const key = `${file.name}_${file.size}`;
            if (!uniqueFiles.has(key)) {
              uniqueFiles.set(key, file);
            }
          });
          
          existingFiles = Array.from(uniqueFiles.values());
          timestamp = result.pdfFilesInfo.timestamp || timestamp;
          console.log(`Retrieved ${existingFiles.length} unique existing files from storage`);
        }
        
        // Store the existing files info back in chrome storage
        // This ensures we don't lose existing files when returning to popup
        chrome.storage.local.set({
          'pdfFilesInfo': {
            files: existingFiles,
            timestamp: timestamp,
            keepExisting: true // Flag to tell popup to keep these files
          }
        }, function() {
          if (chrome.runtime.lastError) {
            console.error('Error saving existing files:', chrome.runtime.lastError);
            alert('Failed to save current file selection. Please try again.');
            return;
          }
          
          console.log(`Successfully stored ${existingFiles.length} files with keepExisting flag`);
          // Now open the popup page to add more files
          chrome.tabs.create({ url: 'popup.html' });
        });
      });
    });
  }

  // Check if required libraries are available
  function checkLibraries() {
    console.log('Checking for required libraries');
    let missingLibraries = [];
    
    try {
      if (typeof pdfjsLib === 'undefined') {
        console.error('PDF.js library not found in global scope');
        missingLibraries.push('PDF.js');
      } else {
        console.log('PDF.js found, version:', pdfjsLib.version || 'unknown');
        // Also check if worker source is set
        if (!pdfjsLib.GlobalWorkerOptions.workerSrc) {
          console.warn('PDF.js worker source not set');
          // Set it explicitly again
          pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
          console.log('Set worker source to:', pdfjsLib.GlobalWorkerOptions.workerSrc);
        }
      }
    } catch (e) {
      console.error('Error checking PDF.js:', e);
      missingLibraries.push('PDF.js');
    }
    
    try {
      if (typeof PDFLib === 'undefined') {
        console.error('PDF-lib library not found in global scope');
        missingLibraries.push('PDF-lib');
      } else {
        console.log('PDF-lib found');
      }
    } catch (e) {
      console.error('Error checking PDF-lib:', e);
      missingLibraries.push('PDF-lib');
    }
    
    try {
      if (typeof Sortable === 'undefined') {
        console.error('Sortable.js library not found in global scope');
        missingLibraries.push('Sortable.js');
      } else {
        console.log('Sortable.js found');
      }
    } catch (e) {
      console.error('Error checking Sortable.js:', e);
      missingLibraries.push('Sortable.js');
    }
    
    if (missingLibraries.length === 0) {
      console.log('All required libraries are available');
    } else {
      console.error('Missing libraries:', missingLibraries);
    }
    
    return missingLibraries;
  }
  
  // Initialize draggable functionality
  function initializeSortable() {
    try {
      console.log('Initializing sortable functionality');
      
      // Set up auto-scrolling variables
      let autoScrollAnimationFrame;
      let isDragging = false;
      let mouseY = 0;
      
      // Function to handle auto-scrolling
      function autoScroll() {
        if (!isDragging) return;
        
        const windowHeight = window.innerHeight;
        const scrollThreshold = 200; // px from top/bottom edge to trigger scrolling (increased for better response)
        const maxScrollSpeed = 25; // Increased maximum scroll speed in pixels per frame
        
        // Calculate distance from top and bottom edges
        const distanceFromTop = mouseY;
        const distanceFromBottom = windowHeight - mouseY;
        
        let scrollAmount = 0;
        
        // Auto-scroll when near top edge
        if (distanceFromTop < scrollThreshold) {
          // Calculate scroll speed based on proximity to edge (closer = faster)
          const scrollPercentage = 1 - (distanceFromTop / scrollThreshold);
          scrollAmount = -Math.ceil(scrollPercentage * maxScrollSpeed);
          document.querySelector('.scroll-indicator-top').style.opacity = scrollPercentage;
        } 
        // Auto-scroll when near bottom edge
        else if (distanceFromBottom < scrollThreshold) {
          // Calculate scroll speed based on proximity to edge (closer = faster)
          const scrollPercentage = 1 - (distanceFromBottom / scrollThreshold);
          scrollAmount = Math.ceil(scrollPercentage * maxScrollSpeed);
          document.querySelector('.scroll-indicator-bottom').style.opacity = scrollPercentage;
        } else {
          // Not near edges, hide indicators
          document.querySelector('.scroll-indicator-top').style.opacity = 0;
          document.querySelector('.scroll-indicator-bottom').style.opacity = 0;
        }
        
        // Perform scrolling if needed
        if (scrollAmount !== 0) {
          window.scrollBy(0, scrollAmount);
        }
        
        // Continue animation loop
        autoScrollAnimationFrame = requestAnimationFrame(autoScroll);
      }
      
      // Track mouse position for auto-scrolling
      document.addEventListener('mousemove', function(e) {
        mouseY = e.clientY;
      });
      
      // Track touch position for auto-scrolling
      document.addEventListener('touchmove', function(e) {
        if (e.touches && e.touches[0]) {
          mouseY = e.touches[0].clientY;
        }
      });
      
      // Ensure the container has correct CSS for scrolling
      document.body.style.height = '100%';
      document.body.style.overflow = 'auto';
      
      // Apply better height to container
      const container = document.querySelector('.container');
      container.style.minHeight = '100vh';
      
      new Sortable(pdfPagesContainer, {
        animation: 150,
        ghostClass: 'sortable-ghost',
        chosenClass: 'sortable-chosen',
        // We'll handle scrolling ourselves
        scroll: false,
        delayOnTouchOnly: true, // Prevents unwanted drags when scrolling on mobile
        delay: 100, // Small delay to make drag and drop feel more natural on touch devices
        onStart: function(evt) {
          // Add dragging class to body when drag starts
          document.body.classList.add('dragging');
          // Show scroll indicators
          document.querySelector('.scroll-indicator-top').style.display = 'block';
          document.querySelector('.scroll-indicator-bottom').style.display = 'block';
          
          // Start auto-scrolling
          isDragging = true;
          if (autoScrollAnimationFrame) {
            cancelAnimationFrame(autoScrollAnimationFrame);
          }
          autoScrollAnimationFrame = requestAnimationFrame(autoScroll);
          
          console.log('Drag started, auto-scrolling activated');
        },
        onEnd: function(evt) {
          // Remove dragging class when drag ends
          document.body.classList.remove('dragging');
          // Hide scroll indicators
          document.querySelector('.scroll-indicator-top').style.display = 'none';
          document.querySelector('.scroll-indicator-bottom').style.display = 'none';
          
          // Stop auto-scrolling
          isDragging = false;
          if (autoScrollAnimationFrame) {
            cancelAnimationFrame(autoScrollAnimationFrame);
          }
          
          console.log('Drag ended, auto-scrolling deactivated');
          updatePageNumbers();
        }
      });
      console.log('Sortable initialized with enhanced auto-scroll');
    } catch (error) {
      console.error('Error initializing Sortable:', error);
      showMessage('Error initializing drag functionality. Please reload the page.', 'error');
    }
  }
  
  // Update page numbers after reordering
  function updatePageNumbers() {
    const pageElements = pdfPagesContainer.querySelectorAll('.pdf-page');
    pageElements.forEach((page, index) => {
      const pageNumber = page.querySelector('.page-number');
      // Display the visual position (1-based)
      pageNumber.textContent = `Page ${index + 1}`;
      // Update visual index only, keep the original-index intact
      page.setAttribute('data-index', index);
      
      // Log the page's current position and the PDF it references
      const originalIndex = page.getAttribute('data-original-index');
      if (originalIndex && originalIndex < pdfPages.length) {
        const pageInfo = pdfPages[originalIndex];
        console.log(`Page at position ${index+1} is page ${pageInfo.pageNum} from "${pageInfo.fileName}"`);
      }
    });
  }
  
  // Load PDFs from chrome storage
  async function loadPDFs() {
    console.log('Attempting to load PDFs from chrome.storage.local');
    showMessage('Loading PDF files...', 'loading');
    
    // Get file info from chrome storage
    chrome.storage.local.get('pdfFilesInfo', async function(result) {
      console.log('Storage retrieval callback executed', result);
      
      if (chrome.runtime.lastError) {
        console.error('Error retrieving file info from storage:', chrome.runtime.lastError);
        showMessage('Error loading PDFs. Please try again.', 'error');
        return;
      }
      
      if (!result.pdfFilesInfo || !result.pdfFilesInfo.files || result.pdfFilesInfo.files.length === 0) {
        console.log('No PDF files found in chrome storage', result);
        showMessage('No PDFs selected. Click "Add More PDFs" to begin.', 'no-pdfs');
        return;
      }
      
      try {
        const filesInfo = result.pdfFilesInfo.files;
        const timestamp = result.pdfFilesInfo.timestamp || Date.now();
        
        console.log(`Found ${filesInfo.length} PDF files in chrome storage (timestamp: ${new Date(timestamp).toLocaleString()})`);
        console.log('First file info:', filesInfo[0] ? 
          {name: filesInfo[0].name, size: filesInfo[0].size, dataLength: filesInfo[0].data?.length || 0} : 'No file info');
        
        // Clear existing PDF documents and pages
        pdfDocuments = [];
        pdfPages = [];
        
        let successCount = 0;
        
        // Track processed files by name to avoid duplicates
        const processedFiles = new Set();
        
        // Process each file from base64 data
        for (let i = 0; i < filesInfo.length; i++) {
          const fileInfo = filesInfo[i];
          
          // Skip duplicates by checking name and size
          const fileKey = `${fileInfo.name}_${fileInfo.size}`;
          if (processedFiles.has(fileKey)) {
            console.log(`Skipping duplicate file: ${fileInfo.name}`);
            continue;
          }
          
          showMessage(`Loading PDF ${successCount+1}/${filesInfo.length}: ${fileInfo.name}`, 'loading');
          
          try {
            console.log(`Processing PDF file: ${fileInfo.name}`, {
              size: fileInfo.size, 
              dataExists: !!fileInfo.data,
              dataLength: fileInfo.data?.length || 0
            });
            
            if (!fileInfo.data) {
              console.error(`No data found for file ${fileInfo.name}`);
              throw new Error(`File data is missing`);
            }
            
            // Convert base64 to array buffer with error checking
            let pdfData;
            try {
              // Decode base64 to binary string
              console.log(`Starting base64 decoding for ${fileInfo.name}`);
              const binaryString = atob(fileInfo.data);
              console.log(`Decoded base64 data for ${fileInfo.name}, length: ${binaryString.length}`);
              
              // Convert binary string to Uint8Array
              const bytes = new Uint8Array(binaryString.length);
              for (let j = 0; j < binaryString.length; j++) {
                bytes[j] = binaryString.charCodeAt(j);
                // Add a progress log for large files
                if (j % 1000000 === 0 && j > 0) {
                  console.log(`Conversion progress: ${j}/${binaryString.length} bytes`);
                }
              }
              
              // Create ArrayBuffer
              pdfData = bytes.buffer;
              console.log(`Successfully converted to ArrayBuffer: ${pdfData.byteLength} bytes`);
              
              // Check first few bytes to ensure it's a PDF
              const header = Array.from(bytes.slice(0, 8)).map(b => String.fromCharCode(b)).join('');
              console.log(`File header: ${header}`);
              if (!header.startsWith('%PDF-')) {
                console.warn(`File doesn't appear to be a valid PDF: ${header}`);
              }
            } catch (decodeError) {
              console.error(`Error decoding base64 data for ${fileInfo.name}:`, decodeError);
              throw new Error(`Failed to decode file data: ${decodeError.message}`);
            }
            
            console.log(`About to call processPDF for ${fileInfo.name}`);
            // Process the PDF with a proper ID that includes the file signature to help avoid duplicates
            await processPDF({
              id: `pdf_${Date.now()}_${i}_${fileInfo.lastModified || 0}`,
              name: fileInfo.name,
              size: fileInfo.size
            }, pdfData);
            
            // Mark this file as processed
            processedFiles.add(fileKey);
            
            successCount++;
            console.log(`Successfully processed ${fileInfo.name}, success count: ${successCount}`);
          } catch (error) {
            console.error(`Error processing PDF ${fileInfo.name}:`, error);
            showMessage(`Error loading "${fileInfo.name}": ${error.message}`, 'error');
            await new Promise(resolve => setTimeout(resolve, 2000)); // Show error briefly
          }
        }
        
        console.log(`Processing complete. Total success: ${successCount}/${filesInfo.length}`);
        if (pdfDocuments.length > 0) {
          console.log(`Initializing sortable with ${pdfDocuments.length} documents`);
          initializeSortable();
          removeMessage();
        } else {
          console.error('No PDFs were successfully loaded');
          showMessage('Failed to load any PDFs. Please try uploading them again.', 'error');
        }
        
      } catch (error) {
        console.error('Error processing file information from chrome storage:', error);
        showMessage('Error loading PDFs. Please try again.', 'error');
      }
    });
  }
  
  // Helper to display messages
  function showMessage(message, className) {
    // Remove old messages of the same class
    const existingMessages = pdfPagesContainer.querySelectorAll(`.${className}`);
    existingMessages.forEach(msg => msg.remove());
    
    const messageDiv = document.createElement('div');
    messageDiv.className = className;
    messageDiv.textContent = message;
    
    // Only clear container if there are no PDF pages yet
    if (pdfPagesContainer.querySelectorAll('.pdf-page').length === 0) {
      pdfPagesContainer.innerHTML = '';
    }
    
    pdfPagesContainer.appendChild(messageDiv);
  }
  
  // Helper to remove messages
  function removeMessage() {
    const messages = pdfPagesContainer.querySelectorAll('.loading, .error, .no-pdfs');
    messages.forEach(msg => msg.remove());
  }
  
  // Process a PDF file
  async function processPDF(fileInfo, fileData) {
    console.log(`Processing PDF: ${fileInfo.name} (${fileData.byteLength} bytes)`);
    
    try {
      // Check if PDF.js is available
      if (typeof pdfjsLib === 'undefined') {
        console.error('PDF.js library not available');
        throw new Error('PDF.js library not available');
      }
      
      console.log('PDF.js is available:', { 
        version: pdfjsLib.version || 'unknown',
        workerSrc: pdfjsLib.GlobalWorkerOptions.workerSrc || 'not set'
      });
      
      // Check if this document is already loaded by comparing ID
      const isDuplicate = pdfDocuments.some(doc => doc.id === fileInfo.id);
      if (isDuplicate) {
        console.warn(`Document with ID ${fileInfo.id} already loaded, skipping`);
        return true; // Return success but don't process duplicate
      }
      
      // Convert to Uint8Array for PDF.js - create a new copy to avoid detached buffer issues
      console.log('Creating Uint8Array from buffer');
      const pdfData = new Uint8Array(fileData.slice(0));
      console.log(`Created Uint8Array, length: ${pdfData.length}`);
      
      // Check if the data appears to be a valid PDF (should start with %PDF-)
      const header = Array.from(pdfData.slice(0, 7)).map(byte => String.fromCharCode(byte)).join('');
      console.log(`Checking PDF header: "${header}"`);
      if (!header.startsWith('%PDF-')) {
        console.error(`File does not appear to be a valid PDF. Header: ${header}`);
        throw new Error('Invalid PDF format');
      }
      
      console.log(`Loading PDF document: ${fileInfo.name}`);
      // Set up PDF.js options with explicit worker source
      const loadingTask = pdfjsLib.getDocument({
        data: pdfData,
        cMapUrl: null,
        cMapPacked: true,
        standardFontDataUrl: null
      });
      
      console.log('PDF loading task created, waiting for promise');
      
      // Update the progress during loading
      loadingTask.onProgress = function(progress) {
        if (progress.total) {
          console.log(`Loading PDF: ${Math.round(progress.loaded / progress.total * 100)}%`);
        }
      };
      
      // Add timeout to detect hanging
      const timeoutMS = 30000; // 30 seconds
      const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error(`PDF loading timed out after ${timeoutMS/1000} seconds`)), timeoutMS);
      });
      
      // Race between loading and timeout
      console.log('Waiting for PDF load or timeout');
      const pdf = await Promise.race([
        loadingTask.promise,
        timeoutPromise
      ]);
      
      console.log(`PDF loaded successfully, contains ${pdf.numPages} pages`);
      
      // Create a copy of the data for merging later
      console.log('Creating data copy for later merging');
      const dataCopy = new Uint8Array(fileData.slice(0));
      
      // Store the document for later use in merging
      console.log('Storing document in memory');
      pdfDocuments.push({
        id: fileInfo.id,
        name: fileInfo.name,
        size: fileInfo.size,
        pdf: pdf,
        data: dataCopy.buffer
      });
      
      // Render all pages
      console.log(`Starting to render pages for ${fileInfo.name}`);
      await renderPDFPages(pdf, fileInfo.name, fileInfo.id);
      console.log(`Finished rendering all pages for ${fileInfo.name}`);
      
      return true;
    } catch (error) {
      console.error(`Error processing PDF ${fileInfo.name}:`, error);
      console.error('Error stack:', error.stack);
      
      if (error.name === 'PasswordException') {
        showMessage(`Error: PDF "${fileInfo.name}" is password protected.`, 'error');
      } else {
        showMessage(`Error processing "${fileInfo.name}": ${error.message}`, 'error');
      }
      await new Promise(resolve => setTimeout(resolve, 3000)); // Show error for 3 seconds
      throw error;
    }
  }
  
  // Render all pages from a PDF
  async function renderPDFPages(pdf, fileName, fileId) {
    console.log(`Rendering ${pdf.numPages} pages from ${fileName}`);
    
    for (let i = 1; i <= pdf.numPages; i++) {
      try {
        console.log(`Getting page ${i} of ${fileName}`);
        const page = await pdf.getPage(i);
        console.log(`Successfully got page ${i}`);
        
        const pageIndex = pdfPages.length;
        
        // Store page info for merging later
        pdfPages.push({
          fileId: fileId,
          pageNum: i,
          fileName: fileName
        });
        
        // Render the page to a canvas
        console.log(`Creating viewport for page ${i}`);
        const viewport = page.getViewport({ scale: 0.5 });
        console.log(`Viewport dimensions: ${viewport.width}x${viewport.height}`);
        
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        
        console.log(`Starting render for page ${i}`);
        try {
          await page.render({
            canvasContext: context,
            viewport: viewport
          }).promise;
          
          console.log(`Page ${i} rendered successfully`);
        } catch (renderError) {
          console.error(`Error rendering page ${i}:`, renderError);
          throw new Error(`Failed to render page ${i}: ${renderError.message}`);
        }
        
        // Create the page element in the UI - pass the page number (i) and index in pdfPages array
        console.log(`Creating page element for page ${i}`);
        const pageElement = createPageElement(canvas, i, fileName, pageIndex);
        pdfPagesContainer.appendChild(pageElement);
        console.log(`Page ${i} element added to container`);
      } catch (error) {
        console.error(`Error processing page ${i} of ${fileName}:`, error);
        console.error('Stack:', error.stack);
        showMessage(`Error rendering page ${i} of ${fileName}: ${error.message}`, 'error');
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }
  }
  
  // Create a page element with thumbnail and info
  function createPageElement(canvas, pageNumber, fileName, dataIndex) {
    const pageElement = document.createElement('div');
    pageElement.className = 'pdf-page';
    pageElement.setAttribute('data-index', dataIndex);
    // Also store the original index to maintain reference to the correct page
    pageElement.setAttribute('data-original-index', dataIndex);
    
    // Create delete button
    const deleteBtn = document.createElement('div');
    deleteBtn.className = 'delete-page';
    deleteBtn.innerHTML = '×';
    deleteBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      if (confirm('Remove this page?')) {
        pageElement.remove();
        updatePageNumbers();
      }
    });
    
    // Create page thumbnail
    const thumbnail = document.createElement('img');
    thumbnail.className = 'pdf-thumbnail';
    thumbnail.src = canvas.toDataURL();
    
    // Create page info
    const pageInfo = document.createElement('div');
    pageInfo.className = 'page-info';
    
    const pageNumberSpan = document.createElement('span');
    pageNumberSpan.className = 'page-number';
    pageNumberSpan.textContent = `Page ${pageNumber}`;
    
    const fileNameSpan = document.createElement('span');
    fileNameSpan.className = 'file-name';
    fileNameSpan.title = fileName;
    fileNameSpan.textContent = fileName;
    
    pageInfo.appendChild(pageNumberSpan);
    pageInfo.appendChild(fileNameSpan);
    
    pageElement.appendChild(deleteBtn);
    pageElement.appendChild(thumbnail);
    pageElement.appendChild(pageInfo);
    
    return pageElement;
  }
  
  // Merge PDFs and download
  async function mergePDFsAndDownload() {
    try {
      // Check if PDF-lib is available
      if (typeof PDFLib === 'undefined') {
        throw new Error('PDF-lib library not available');
      }
      
      const pageElements = pdfPagesContainer.querySelectorAll('.pdf-page');
      
      if (pageElements.length === 0) {
        alert('No pages to merge. Please add PDFs first.');
        return;
      }
      
      mergeDownloadBtn.textContent = 'Processing...';
      mergeDownloadBtn.disabled = true;
      
      console.log('Starting PDF merge process');
      
      // Create a new PDF document using pdf-lib
      const { PDFDocument } = PDFLib;
      const mergedPdf = await PDFDocument.create();
      
      // Get the current visual order of pages from the UI
      // Each page element has a data-original-index attribute that points to its entry in pdfPages
      const pageOrder = Array.from(pageElements).map(el => {
        return parseInt(el.getAttribute('data-original-index'));
      });
      
      console.log('Page order for merging:', pageOrder);
      
      // Track our progress
      let pagesProcessed = 0;
      showMessage(`Merging pages: 0/${pageOrder.length}`, 'loading');
      
      // Add each page to the new document in the current visual order
      for (const pageIndex of pageOrder) {
        if (pageIndex >= pdfPages.length) {
          console.error(`Invalid page index: ${pageIndex}, max is ${pdfPages.length - 1}`);
          continue;
        }
        
        const pageInfo = pdfPages[pageIndex];
        console.log(`Adding page ${pageInfo.pageNum} from ${pageInfo.fileName}`);
        
        const pdfDoc = pdfDocuments.find(doc => doc.id === pageInfo.fileId);
        
        if (pdfDoc) {
          try {
            // Load the source PDF document - create a fresh copy to prevent detached buffer issues
            const sourcePdfBytes = new Uint8Array(pdfDoc.data.slice(0));
            const sourcePdf = await PDFDocument.load(sourcePdfBytes);
            
            // Copy the page (0-indexed in pdf-lib)
            const [copiedPage] = await mergedPdf.copyPages(sourcePdf, [pageInfo.pageNum - 1]);
            
            // Add it to the new document
            mergedPdf.addPage(copiedPage);
            
            pagesProcessed++;
            if (pagesProcessed % 5 === 0 || pagesProcessed === pageOrder.length) {
              showMessage(`Merging pages: ${pagesProcessed}/${pageOrder.length}`, 'loading');
            }
            
            console.log(`Page added successfully`);
          } catch (error) {
            console.error(`Error adding page ${pageInfo.pageNum} from ${pageInfo.fileName}:`, error);
          }
        } else {
          console.error(`PDF document with ID ${pageInfo.fileId} not found`);
        }
      }
      
      if (pagesProcessed === 0) {
        showMessage('Error: Could not merge any pages', 'error');
        mergeDownloadBtn.textContent = 'Merge & Download';
        mergeDownloadBtn.disabled = false;
        return;
      }
      
      // Save the merged PDF
      console.log('Saving merged PDF');
      showMessage(`Finalizing document...`, 'loading');
      
      const mergedPdfBytes = await mergedPdf.save();
      
      // Check if the PDF has content
      if (mergedPdfBytes.length < 100) {
        console.error('Generated PDF is too small, likely empty');
        showMessage('Error: Generated PDF appears to be empty', 'error');
        mergeDownloadBtn.textContent = 'Merge & Download';
        mergeDownloadBtn.disabled = false;
        return;
      }
      
      console.log(`Generated PDF size: ${mergedPdfBytes.length} bytes`);
      
      // Create and trigger download
      const blob = new Blob([mergedPdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'merged_document.pdf';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      console.log('PDF successfully merged and download initiated');
      removeMessage();
      
      mergeDownloadBtn.textContent = 'Merge & Download';
      mergeDownloadBtn.disabled = false;
      
    } catch (error) {
      console.error('Error merging PDFs:', error);
      alert('Error merging PDFs. Please try again.');
      mergeDownloadBtn.textContent = 'Merge & Download';
      mergeDownloadBtn.disabled = false;
    }
  }
  
  // Process a new file
  async function processNewFile(file) {
    try {
      // Read the file
      const fileData = await readFileAsArrayBuffer(file);
      
      // Generate a unique ID
      const fileId = `pdf_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
      
      // Process the PDF
      await processPDF({
        id: fileId,
        name: file.name,
        size: file.size
      }, fileData);
      
      return true;
    } catch (error) {
      console.error(`Error processing file ${file.name}:`, error);
      return false;
    }
  }
  
  // Helper to read file as array buffer
  function readFileAsArrayBuffer(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = function(e) {
        resolve(e.target.result);
      };
      reader.onerror = function(e) {
        console.error(`Error reading file ${file.name}:`, e);
        reject(e);
      };
      reader.readAsArrayBuffer(file);
    });
  }
}); 