// This file is intentionally empty.
// It's referenced in popup.html for future functionality if needed. 