// Store selected files in memory
let selectedFiles = [];

document.addEventListener('DOMContentLoaded', function() {
  const fileInput = document.getElementById('pdf-upload');
  const fileCount = document.getElementById('file-count');
  const mergeBtn = document.getElementById('merge-btn');
  
  console.log('PDF Merger popup initialized');
  
  // Check if we have existing files in storage
  chrome.storage.local.get('pdfFilesInfo', function(result) {
    console.log('Checking for existing PDF files in storage', result);
    
    if (result.pdfFilesInfo && result.pdfFilesInfo.keepExisting && 
        result.pdfFilesInfo.files && result.pdfFilesInfo.files.length > 0) {
      console.log(`Found ${result.pdfFilesInfo.files.length} existing files with keepExisting flag`);
      
      // We'll proceed to the manager page with the existing files
      chrome.tabs.create({ url: 'manager.html' });
      
      // Clear the keepExisting flag so this doesn't happen again
      chrome.storage.local.set({
        'pdfFilesInfo': {
          files: result.pdfFilesInfo.files,
          timestamp: result.pdfFilesInfo.timestamp || Date.now()
          // No keepExisting flag
        }
      }, function() {
        if (chrome.runtime.lastError) {
          console.error('Error updating storage after keepExisting:', chrome.runtime.lastError);
        } else {
          console.log('Successfully updated storage, removed keepExisting flag');
        }
      });
    } else {
      console.log('No existing files with keepExisting flag found');
    }
  });
  
  // File input change event
  fileInput.addEventListener('change', function(event) {
    selectedFiles = Array.from(event.target.files);
    console.log(`Selected ${selectedFiles.length} files:`, selectedFiles.map(f => ({name: f.name, type: f.type, size: f.size})));
    
    // Filter out non-PDF files
    const pdfFiles = selectedFiles.filter(file => file.type === 'application/pdf');
    if (pdfFiles.length < selectedFiles.length) {
      console.warn(`Filtered out ${selectedFiles.length - pdfFiles.length} non-PDF files`);
      selectedFiles = pdfFiles;
      alert(`Note: Only PDF files will be processed (${pdfFiles.length} out of ${event.target.files.length} selected files).`);
    }
    
    fileCount.textContent = selectedFiles.length;
    mergeBtn.disabled = selectedFiles.length === 0;
    
    console.log(`Selected ${selectedFiles.length} PDF files`);
  });
  
  // Merge button click event
  mergeBtn.addEventListener('click', function() {
    if (selectedFiles.length === 0) {
      console.log('No files selected');
      return;
    }
    
    console.log(`Processing ${selectedFiles.length} PDF files for storage`);
    showLoading(true, 'Reading files...');
    
    // Process files to base64
    processFilesToBase64(selectedFiles)
      .then(filesInfo => {
        if (filesInfo.length === 0) {
          throw new Error('No files could be processed');
        }
        
        showLoading(true, 'Storing files...');
        console.log(`Attempting to store ${filesInfo.length} files in chrome.storage.local`);
        
        // Check if we're adding to existing files
        chrome.storage.local.get('pdfFilesInfo', function(result) {
          let allFiles = filesInfo;
          
          // If we should keep existing files, combine them with new files
          if (result.pdfFilesInfo && result.pdfFilesInfo.files && 
              result.pdfFilesInfo.files.length > 0) {
            
            // Check for keepExisting flag
            const keepExisting = result.pdfFilesInfo.keepExisting === true;
            
            if (keepExisting) {
              console.log(`Adding to ${result.pdfFilesInfo.files.length} existing files (keepExisting flag is set)`);
              
              // Create a map of existing files to avoid duplicates
              const existingFileMap = new Map();
              result.pdfFilesInfo.files.forEach(file => {
                const key = `${file.name}_${file.size}`;
                existingFileMap.set(key, file);
              });
              
              // Add only new files that don't already exist (by name and size)
              const newFiles = [];
              filesInfo.forEach(file => {
                const key = `${file.name}_${file.size}`;
                if (!existingFileMap.has(key)) {
                  newFiles.push(file);
                  console.log(`Adding new file: ${file.name}`);
                } else {
                  console.log(`Skipping duplicate file: ${file.name}`);
                }
              });
              
              // Combine existing files with new files
              allFiles = [...result.pdfFilesInfo.files, ...newFiles];
              console.log(`Combined ${result.pdfFilesInfo.files.length} existing and ${newFiles.length} new files`);
            } else {
              // If keepExisting is not true, replace all files
              console.log(`Replacing ${result.pdfFilesInfo.files.length} existing files with ${filesInfo.length} new files`);
              allFiles = filesInfo;
            }
          }
          
          // Verify data integrity before storing
          allFiles.forEach((file, index) => {
            if (!file.data) {
              console.error(`File at index ${index} is missing data:`, file);
              throw new Error(`File "${file.name}" is missing data`);
            }
          });
          
          // Clear existing data to avoid storage conflicts
          chrome.storage.local.clear(function() {
            if (chrome.runtime.lastError) {
              console.warn('Error clearing storage:', chrome.runtime.lastError);
            }
            
            // Store all files
            chrome.storage.local.set({
              'pdfFilesInfo': {
                files: allFiles,
                timestamp: Date.now()
                // Don't set keepExisting flag here
              }
            }, function() {
              if (chrome.runtime.lastError) {
                console.error('Error storing files:', chrome.runtime.lastError);
                showLoading(false);
                alert('Error: Files may be too large. Try selecting fewer or smaller files.');
                return;
              }
              
              console.log(`Successfully stored ${allFiles.length} files in chrome.storage.local`);
              chrome.tabs.create({ url: 'manager.html' });
            });
          });
        });
      })
      .catch(error => {
        console.error('Error processing files:', error);
        showLoading(false);
        alert(`Error: ${error.message}`);
      });
  });

  // Function to show loading state
  function showLoading(show, message = 'Processing...') {
    const loader = document.getElementById('loader');
    const loaderMessage = document.getElementById('loader-message');
    
    if (show) {
      loader.style.display = 'flex';
      loaderMessage.textContent = message;
      mergeBtn.disabled = true;
      fileInput.disabled = true;
    } else {
      loader.style.display = 'none';
      mergeBtn.disabled = selectedFiles.length === 0;
      fileInput.disabled = false;
    }
  }

  // Process files to base64
  async function processFilesToBase64(files) {
    const filesInfo = [];
    
    for (const file of files) {
      // Skip non-PDF files
      if (file.type !== 'application/pdf') {
        console.warn(`Skipping non-PDF file: ${file.name}`);
        continue;
      }
      
      try {
        console.log(`Processing file: ${file.name} (${formatFileSize(file.size)})`);
        const base64Data = await readFileAsBase64(file);
        
        if (!base64Data) {
          console.error(`No base64 data generated for ${file.name}`);
          throw new Error(`Failed to read file data for ${file.name}`);
        }
        
        console.log(`Successfully encoded ${file.name} to base64, length: ${base64Data.length}`);
        
        // Add file info to array
        filesInfo.push({
          name: file.name,
          size: file.size,
          type: file.type,
          lastModified: file.lastModified,
          data: base64Data
        });
        
        console.log(`Processed file: ${file.name} (${formatFileSize(file.size)})`);
      } catch (error) {
        console.error(`Error processing file ${file.name}:`, error);
        throw new Error(`Failed to process ${file.name}: ${error.message}`);
      }
    }
    
    return filesInfo;
  }
  
  // Read file as base64
  function readFileAsBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = function(event) {
        if (!event.target.result) {
          console.error(`FileReader result is empty for ${file.name}`);
          reject(new Error('File read resulted in empty data'));
          return;
        }
        
        try {
          // Extract base64 data from data URL
          const dataUrl = event.target.result;
          
          if (typeof dataUrl !== 'string' || !dataUrl.includes('base64,')) {
            console.error(`Invalid data URL format for ${file.name}:`, dataUrl);
            reject(new Error('Invalid data URL format'));
            return;
          }
          
          const base64 = dataUrl.split(',')[1];
          console.log(`Base64 data extracted for ${file.name}, length: ${base64.length}`);
          
          resolve(base64);
        } catch (error) {
          console.error(`Error extracting base64 data for ${file.name}:`, error);
          reject(error);
        }
      };
      
      reader.onerror = function(error) {
        console.error(`FileReader error for ${file.name}:`, error);
        reject(error);
      };
      
      console.log(`Starting to read ${file.name} as data URL`);
      reader.readAsDataURL(file);
    });
  }
  
  // Format file size
  function formatFileSize(bytes) {
    if (bytes < 1024) return bytes + ' bytes';
    else if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
    else return (bytes / 1048576).toFixed(1) + ' MB';
  }
}); 