// Breathing exercise configurations
const exercises = {
  box: {
    name: 'Box Breathing',
    phases: [
      { name: 'Inhale', duration: 4 },
      { name: 'Hold', duration: 4 },
      { name: 'Exhale', duration: 4 },
      { name: 'Hold', duration: 4 }
    ]
  },
  478: {
    name: '4-7-8 Breathing',
    phases: [
      { name: 'Inhale', duration: 4 },
      { name: 'Hold', duration: 7 },
      { name: 'Exhale', duration: 8 }
    ]
  },
  calm: {
    name: 'Calm Breathing',
    phases: [
      { name: 'Inhale', duration: 4 },
      { name: 'Hold', duration: 4 },
      { name: 'Exhale', duration: 6 },
      { name: 'Hold', duration: 2 }
    ]
  }
};

// State management
let currentExercise = 'box';
let isExerciseRunning = false;
let currentPhase = 'inhale';
let startTime = null;
let lastFrameTime = null;
let animationFrameId = null;
let isPaused = false;
let pauseTime = null;

// DOM Elements
const circle = document.querySelector('.circle-inner');
const timerText = document.getElementById('timer-text');
const phaseText = document.querySelector('.phase-text');
const progressBar = document.querySelector('.progress');
const startBtn = document.getElementById('start-btn');
const pauseBtn = document.getElementById('pause-btn');
const resetBtn = document.getElementById('reset-btn');
const exerciseBtns = document.querySelectorAll('.exercise-btn');
const animationDot = document.querySelector('.animation-dot');
const phaseLabels = document.querySelectorAll('.phase-label');
const themeToggle = document.getElementById('theme-toggle');
const container = document.querySelector('.breathing-container');

// Animation state
const animationState = {
  frameId: null,
  startTime: null,
  currentPhase: 0
};

// Animation states for different exercises
const animationStates = {
  // Box breathing (4-4-4-4)
  'box': {
    'inhale': {
      duration: 4,
      startPosition: { x: 10, y: 10 },
      endPosition: { x: 90, y: 10 },
      text: 'Inhale'
    },
    'hold1': {
      duration: 4,
      startPosition: { x: 90, y: 10 },
      endPosition: { x: 90, y: 90 },
      text: 'Hold'
    },
    'exhale': {
      duration: 4,
      startPosition: { x: 90, y: 90 },
      endPosition: { x: 10, y: 90 },
      text: 'Exhale'
    },
    'hold2': {
      duration: 4,
      startPosition: { x: 10, y: 90 },
      endPosition: { x: 10, y: 10 },
      text: 'Hold'
    }
  },
  
  // 4-7-8 breathing (curved arc pattern)
  '478': {
    'inhale': {
      duration: 4,
      startPosition: { x: 10, y: 90 },
      endPosition: { x: 10, y: 10 },
      text: 'Inhale'
    },
    'hold': {
      duration: 7,
      startPosition: { x: 10, y: 10 },
      endPosition: { x: 90, y: 10 },
      text: 'Hold'
    },
    'exhale': {
      duration: 8,
      startPosition: { x: 90, y: 10 },
      endPosition: { x: 10, y: 90 },
      text: 'Exhale'
    },
    'transition': {
      duration: 1.5, // Increased from 0.5s to 1.5s to be more noticeable
      startPosition: { x: 10, y: 90 },
      endPosition: { x: 10, y: 90 },
      text: 'Get Ready'
    }
  },
  
  // Calm breathing (oval pattern)
  'calm': {
    'inhale': {
      duration: 4,
      startPosition: { x: 50, y: 10 },
      endPosition: { x: 90, y: 50 },
      text: 'Inhale'
    },
    'exhale': {
      duration: 6,
      startPosition: { x: 90, y: 50 },
      endPosition: { x: 50, y: 90 },
      text: 'Exhale slowly'
    },
    'exhale2': {
      duration: 4,
      startPosition: { x: 50, y: 90 },
      endPosition: { x: 10, y: 50 },
      text: 'Exhale'
    },
    'inhale2': {
      duration: 4,
      startPosition: { x: 10, y: 50 },
      endPosition: { x: 50, y: 10 },
      text: 'Inhale deeply'
    }
  }
};

// Theme management
const setTheme = (isDark) => {
  document.documentElement.setAttribute('data-theme', isDark ? 'dark' : 'light');
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
  console.log('[DEBUG] Theme set to:', isDark ? 'dark' : 'light');
};

const toggleTheme = () => {
  const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
  const isDark = currentTheme === 'dark';
  const newTheme = isDark ? 'light' : 'dark';
  
  console.log('[DEBUG] Current theme:', currentTheme);
  console.log('[DEBUG] Toggling to theme:', newTheme);
  
  // Set the theme attribute directly on html element
  document.documentElement.setAttribute('data-theme', newTheme);
  localStorage.setItem('theme', newTheme);
};

// Initialize theme
const initTheme = () => {
  const savedTheme = localStorage.getItem('theme') || 'light';
  console.log('[DEBUG] Initializing theme from localStorage:', savedTheme);
  document.documentElement.setAttribute('data-theme', savedTheme);
};

// Initialize app after DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  console.log('[DEBUG] DOM content loaded, initializing app');
  
  // Initialize theme first
  initTheme();
  
  // Get DOM elements
  const startBtn = document.getElementById('start-btn');
  const pauseBtn = document.getElementById('pause-btn');
  const resetBtn = document.getElementById('reset-btn');
  const exerciseBtns = document.querySelectorAll('.exercise-btn');
  const breathingContainer = document.querySelector('.breathing-container');
  const themeToggle = document.getElementById('theme-toggle');
  
  // Debug DOM elements
  console.log('[DEBUG] startBtn:', startBtn);
  console.log('[DEBUG] pauseBtn:', pauseBtn);
  console.log('[DEBUG] resetBtn:', resetBtn);
  console.log('[DEBUG] exerciseBtns:', exerciseBtns);
  console.log('[DEBUG] breathingContainer:', breathingContainer);
  console.log('[DEBUG] themeToggle:', themeToggle);
  
  // Set initial exercise type
  if (breathingContainer) {
    breathingContainer.dataset.exercise = currentExercise;
    console.log('[DEBUG] Set initial exercise to:', currentExercise);
  } else {
    console.error('[ERROR] Could not find breathing container');
  }

  // Initialize dot position on page load (before starting)
  initializeDotPosition();

  // Exercise selection
  if (exerciseBtns && exerciseBtns.length > 0) {
    exerciseBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const exercise = btn.dataset.exercise;
        console.log('[DEBUG] Exercise button clicked:', exercise);
        
        // Update active button
        exerciseBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        
        // Update current exercise
        currentExercise = exercise;
        
        // Update container state - IMPORTANT for shape display
        const breathingContainer = document.querySelector('.breathing-container');
        if (breathingContainer) {
          breathingContainer.dataset.exercise = exercise;
          console.log('[DEBUG] Updated container exercise attribute to:', exercise, 'Current data-exercise=', breathingContainer.dataset.exercise);
        } else {
          console.error('[ERROR] Container not found');
        }
        
        // Reset if currently running
        if (isExerciseRunning) {
          resetExercise();
        } else {
          // If not running, just update dot position for the new exercise
          initializeDotPosition();
        }
      });
    });
  } else {
    console.error('[ERROR] Exercise buttons not found');
  }

  // Theme toggle (set up only if not already done)
  if (themeToggle && !themeToggle._hasToggleListener) {
    themeToggle.addEventListener('click', () => {
      console.log('[DEBUG] Theme toggle clicked');
      toggleTheme();
    });
    themeToggle._hasToggleListener = true;
  } else if (!themeToggle) {
    console.error('[ERROR] Theme toggle not found');
  }

  // Add other event listeners
  setupControlEventListeners(startBtn, pauseBtn, resetBtn);
  
  // Set initial timer text
  const timerText = document.getElementById('timer-text');
  if (timerText) {
    timerText.textContent = '4';
    console.log('[DEBUG] Set initial timer text');
  }

  console.log('[DEBUG] Initialization complete');
});

// Set up control button event listeners
const setupControlEventListeners = (startBtn, pauseBtn, resetBtn) => {
  if (!startBtn || !pauseBtn || !resetBtn) {
    console.error('[ERROR] Control buttons not found');
    return;
  }
  
  // Start button
  startBtn.addEventListener('click', () => {
    console.log('[DEBUG] Start/Resume button clicked');
    if (isExerciseRunning && isPaused) {
      resumeExercise();
    } else {
      startExercise();
    }
  });
  
  // Pause button
  pauseBtn.addEventListener('click', () => {
    console.log('[DEBUG] Pause button clicked');
    pauseExercise();
  });
  
  // Reset button
  resetBtn.addEventListener('click', () => {
    console.log('[DEBUG] Reset button clicked');
    resetExercise();
  });
  
  // Keyboard controls
  document.addEventListener('keydown', (e) => {
    switch (e.key) {
      case ' ':  // Space bar
        if (isExerciseRunning) {
          if (isPaused) {
            resumeExercise();
          } else {
            pauseExercise();
          }
        } else {
          startExercise();
        }
        break;
      case 'r':  // Reset
      case 'R':
        resetExercise();
        break;
      case '1':  // Box breathing
        document.querySelector('.exercise-btn[data-exercise="box"]')?.click();
        break;
      case '2':  // 4-7-8 breathing
        document.querySelector('.exercise-btn[data-exercise="478"]')?.click();
        break;
      case '3':  // Calm breathing
        document.querySelector('.exercise-btn[data-exercise="calm"]')?.click();
        break;
    }
  });
  
  console.log('[DEBUG] Control event listeners set up');
};

// Update the position of the animation dot
function updateDotPosition(phase, progress) {
  const exerciseType = currentExercise;
  const states = animationStates[exerciseType];
  
  if (!states || !states[phase]) {
    console.error('[ERROR] Animation state not found for', exerciseType, phase);
    return;
  }
  
  const currentState = states[phase];
  
  const { startPosition, endPosition } = currentState;
  
  // Calculate exact position based on progress
  const x = startPosition.x + (endPosition.x - startPosition.x) * progress;
  const y = startPosition.y + (endPosition.y - startPosition.y) * progress;
  
  const dot = document.querySelector('.animation-dot');
  if (dot) {
    // Set position directly for better performance
    requestAnimationFrame(() => {
      dot.style.left = `${x}%`;
      dot.style.top = `${y}%`;
    });
    
    // Log position occasionally for debugging
    if (progress % 0.25 < 0.01) {
      console.log(`[DEBUG] Dot position: x=${x.toFixed(1)}%, y=${y.toFixed(1)}%, phase=${phase}, progress=${progress.toFixed(2)}`);
    }
  } else {
    console.error('[ERROR] Animation dot not found');
  }
  
  // Update the text to show current phase
  updateBreathingText(currentState.text, true);
}

// Easing function for smoother animations
const easeInOutQuad = (t) => {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
};

// Update animation
function updateAnimation() {
  if (!isExerciseRunning) return;
  
  const now = Date.now();
  const states = animationStates[currentExercise];
  
  if (!states || !states[currentPhase]) {
    console.error('[ERROR] Animation state not found in updateAnimation', currentPhase);
    // Reset to inhale phase if current phase isn't found
    currentPhase = 'inhale';
    startTime = now;
    return;
  }
  
  const currentState = states[currentPhase];
  
  const phaseStartTime = startTime;
  const elapsed = now - phaseStartTime;
  const phaseDuration = currentState.duration * 1000;
  const progress = Math.min(elapsed / phaseDuration, 1);
  
  // Apply easing for smoother motion
  const easedProgress = easeInOutQuad(progress);
  
  // Special handling for the hold phase in 4-7-8 breathing
  let visualProgress = easedProgress;
  if (currentExercise === '478' && currentPhase === 'hold') {
    // For the 7-second hold, create a subtle pulsing effect
    // that helps the user maintain attention during the longer hold
    const pulseFrequency = 3.5; // About 3-4 gentle pulses during the 7s hold
    const pulseDepth = 0.02; // Very subtle vertical movement (2%)
    
    // Apply subtle visual indicators for the hold progress
    const dot = document.querySelector('.animation-dot');
    if (dot) {
      // Add a subtle up-down floating motion during hold
      const baseY = 10 + Math.sin(progress * pulseFrequency * Math.PI) * pulseDepth * 10;
      
      // Change dot opacity slightly to provide visual feedback
      const baseOpacity = 0.9 + Math.sin(progress * pulseFrequency * Math.PI) * 0.1;
      
      requestAnimationFrame(() => {
        dot.style.top = `${baseY}%`;
        dot.style.opacity = baseOpacity;
      });
    }
    
    // Keep horizontal progress normal for the longer line
    visualProgress = easedProgress;
  }
  
  // Update dot position with easing and visual effects applied
  updateDotPosition(currentPhase, visualProgress);
  
  // Update timer
  const timeLeft = Math.ceil((phaseDuration - elapsed) / 1000);
  const timerText = document.getElementById('timer-text');
  if (timerText) {
    timerText.textContent = Math.max(timeLeft, 1);
  } else {
    console.error('[ERROR] Timer text element not found');
  }
  
  // Update breathing text
  const breathingText = document.querySelector('.breathing-text');
  if (breathingText) {
    breathingText.textContent = currentState.text;
    breathingText.classList.add('active');
  }
  
  // Move to next phase if current phase is complete
  if (progress >= 1) {
    console.log('[DEBUG] Phase complete:', currentPhase);
    const phases = Object.keys(states);
    const currentIndex = phases.indexOf(currentPhase);
    const nextIndex = (currentIndex + 1) % phases.length;
    currentPhase = phases[nextIndex];
    
    // For the transition phase in 4-7-8 breathing, make it more noticeable
    if (currentExercise === '478' && currentPhase === 'transition') {
      // Update breathing text immediately for transition phase
      const breathingText = document.querySelector('.breathing-text');
      if (breathingText) {
        breathingText.textContent = states[currentPhase].text;
        breathingText.classList.add('active');
        // Make text more prominent for the transition phase
        breathingText.style.fontSize = '18px';
        breathingText.style.fontWeight = 'bold';
        
        // Reset styling after transition
        setTimeout(() => {
          breathingText.style.fontSize = '';
          breathingText.style.fontWeight = '';
        }, states[currentPhase].duration * 1000);
      }
    }
    
    console.log('[DEBUG] Moving to next phase:', currentPhase);
    startTime = now;
  }
  
  // Continue animation with optimal timing
  if (isExerciseRunning) {
    animationFrameId = requestAnimationFrame(updateAnimation);
  }
}

// Start the breathing exercise
function startExercise() {
  if (isExerciseRunning) return;
  
  console.log('[DEBUG] Starting exercise:', currentExercise);
  
  // Reset phase to initial state
  currentPhase = 'inhale';
  
  // Update UI state
  isExerciseRunning = true;
  isPaused = false;
  startTime = Date.now();
  
  // Update button state
  const startBtn = document.getElementById('start-btn');
  const pauseBtn = document.getElementById('pause-btn');
  
  if (startBtn) startBtn.style.display = 'none';
  if (pauseBtn) pauseBtn.style.display = 'block';
  if (document.getElementById('reset-btn')) {
    document.getElementById('reset-btn').disabled = false;
  }
  
  // Initialize dot position using the shared function
  initializeDotPosition();
  
  // Ensure the container has the right exercise type
  const container = document.querySelector('.breathing-container');
  if (container) {
    container.dataset.exercise = currentExercise;
    console.log('[DEBUG] Set breathing container data-exercise attribute to:', currentExercise);
  }
  
  // Start animation immediately
  animationFrameId = requestAnimationFrame(updateAnimation);
  
  console.log('[DEBUG] Exercise started');
}

// Pause the breathing exercise
const pauseExercise = () => {
  if (!isExerciseRunning || isPaused) return;
  
  console.log('[DEBUG] Pausing exercise');
  
  isPaused = true;
  pauseTime = Date.now();
  
  // Update button state
  const startBtn = document.getElementById('start-btn');
  const pauseBtn = document.getElementById('pause-btn');
  
  if (startBtn) startBtn.style.display = 'block';
  if (pauseBtn) pauseBtn.style.display = 'none';
  
  // Cancel animation frame
  if (animationFrameId) {
    cancelAnimationFrame(animationFrameId);
    animationFrameId = null;
  }
  
  console.log('[DEBUG] Exercise paused');
};

// Resume the breathing exercise
const resumeExercise = () => {
  if (!isExerciseRunning || !isPaused) return;
  
  console.log('[DEBUG] Resuming exercise');
  
  isPaused = false;
  
  // Adjust start time to account for pause duration
  const pauseDuration = Date.now() - pauseTime;
  startTime += pauseDuration;
  
  // Update button state
  const startBtn = document.getElementById('start-btn');
  const pauseBtn = document.getElementById('pause-btn');
  
  if (startBtn) startBtn.style.display = 'none';
  if (pauseBtn) pauseBtn.style.display = 'block';
  
  // Resume animation
  animationFrameId = requestAnimationFrame(updateAnimation);
  
  console.log('[DEBUG] Exercise resumed');
};

// Reset the breathing exercise
const resetExercise = () => {
  console.log('[DEBUG] Resetting exercise');
  
  // Cancel animation frame
  if (animationFrameId) {
    cancelAnimationFrame(animationFrameId);
    animationFrameId = null;
  }
  
  // Reset state
  isExerciseRunning = false;
  isPaused = false;
  
  // Update button state
  const startBtn = document.getElementById('start-btn');
  const pauseBtn = document.getElementById('pause-btn');
  
  if (startBtn) startBtn.style.display = 'block';
  if (pauseBtn) pauseBtn.style.display = 'none';
  
  // Reset timer
  const timerText = document.getElementById('timer-text');
  if (timerText) timerText.textContent = '4';
  
  // Reset dot position using the shared function
  initializeDotPosition();
  
  // Reset phase text
  updatePhaseText('inhale');
  
  console.log('[DEBUG] Exercise reset complete');
};

// Add tooltips for keyboard shortcuts
try {
  document.querySelector('[data-exercise="box"]').title = 'Box Breathing (Space to start/pause)';
  document.querySelector('[data-exercise="478"]').title = '4-7-8 Breathing (Space to start/pause)';
} catch (error) {
  console.error(`Tooltip addition: ${error.message}`);
}

// Add session tracking
const trackSession = () => {
  try {
    const session = {
      exercise: currentExercise,
      startTime: startTime,
      duration: Date.now() - startTime,
      completedPhases: currentPhase
    };
    
    chrome.storage.local.get(['sessions'], (result) => {
      const sessions = result.sessions || [];
      sessions.push(session);
      chrome.storage.local.set({ sessions });
    });
  } catch (error) {
    log.error(`Session tracking: ${error.message}`);
    showError(`An error occurred: ${error.message}`);
  }
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  try {
    initTheme();
    addTooltips();
    
    // Set initial timer text
    document.getElementById('timer-text').textContent = '4';
    
    log.info('Breathing Assistant initialized');
  } catch (error) {
    log.error(`Initialization: ${error.message}`);
    showError(`An error occurred: ${error.message}`);
  }
});

// Add this function to test the shapes visibility
document.addEventListener('DOMContentLoaded', () => {
  // Debug function for shape testing
  function testShapes() {
    console.log('[DEBUG] Testing shapes visibility');
    
    const container = document.querySelector('.breathing-container');
    if (!container) {
      console.error('[ERROR] Container not found');
      return;
    }
    
    console.log('[DEBUG] Current container data-exercise:', container.dataset.exercise);
    
    // Test triangle shape
    setTimeout(() => {
      console.log('[DEBUG] Setting to trapezoid (478)');
      container.dataset.exercise = '478';
      document.querySelector('[data-exercise="478"]').classList.add('active');
      document.querySelector('[data-exercise="box"]').classList.remove('active');
    }, 2000);
    
    // Switch back to box
    setTimeout(() => {
      console.log('[DEBUG] Setting to box');
      container.dataset.exercise = 'box';
      document.querySelector('[data-exercise="box"]').classList.add('active');
      document.querySelector('[data-exercise="478"]').classList.remove('active');
    }, 4000);
  }
  
  // Disabled automatic shape testing
  // testShapes();
});

// Add direct console access for manual testing
console.log('To test shapes manually, run this command in console:');
console.log('document.querySelector(".breathing-container").dataset.exercise = "478"');
console.log('or');
console.log('document.querySelector(".breathing-container").dataset.exercise = "box"');

// Function to update the phase text
const updatePhaseText = (phase) => {
  const phaseText = document.getElementById('phase-text');
  if (!phaseText) {
    console.error('[ERROR] Phase text element not found');
    return;
  }
  
  // Update phase text based on the phase
  switch (phase) {
    case 'inhale':
      phaseText.textContent = 'Inhale';
      break;
    case 'hold1':
      phaseText.textContent = 'Hold';
      break;
    case 'exhale':
      phaseText.textContent = 'Exhale';
      break;
    case 'hold2':
      phaseText.textContent = 'Hold';
      break;
    default:
      phaseText.textContent = '';
  }
  
  console.log('[DEBUG] Updated phase text to:', phaseText.textContent);
};

// Calculate total cycle time in milliseconds
const getTotalCycleTime = () => {
  const states = animationStates[currentExercise];
  if (!states) {
    console.error('[ERROR] Animation states not found for exercise:', currentExercise);
    return 16000; // Default to 16 seconds (4+4+4+4)
  }
  
  let totalTime = 0;
  Object.values(states).forEach(state => {
    totalTime += state.duration * 1000;
  });
  
  return totalTime;
};

// Calculate the current phase and progress within that phase
const calculatePhaseAndProgress = (cyclePlacement) => {
  const states = animationStates[currentExercise];
  if (!states) {
    console.error('[ERROR] Animation states not found');
    return { currentPhase: 'inhale', phaseProgress: 0 };
  }
  
  let accumulatedTime = 0;
  let currentPhase = '';
  let phaseProgress = 0;
  
  // Find the current phase based on time
  for (const [phase, state] of Object.entries(states)) {
    const phaseDuration = state.duration * 1000;
    if (cyclePlacement < accumulatedTime + phaseDuration) {
      currentPhase = phase;
      phaseProgress = (cyclePlacement - accumulatedTime) / phaseDuration;
      break;
    }
    accumulatedTime += phaseDuration;
  }
  
  // Default to first phase if not found
  if (!currentPhase) {
    const phases = Object.keys(states);
    currentPhase = phases[0] || 'inhale';
    phaseProgress = 0;
  }
  
  return { currentPhase, phaseProgress };
};

// Update timer display
const updateTimer = (phase, progress) => {
  const timerText = document.getElementById('timer-text');
  if (!timerText) {
    console.error('[ERROR] Timer text element not found');
    return;
  }
  
  const states = animationStates[currentExercise];
  if (!states || !states[phase]) {
    console.error('[ERROR] Phase not found in animation states');
    return;
  }
  
  const phaseDuration = states[phase].duration;
  const timeLeft = Math.ceil(phaseDuration * (1 - progress));
  
  timerText.textContent = Math.max(timeLeft, 1);
  console.log('[DEBUG] Updated timer to:', timerText.textContent);
};

// Function to update the breathing text display
function updateBreathingText(text, isActive) {
  const breathingText = document.querySelector('.breathing-text');
  if (breathingText) {
    breathingText.textContent = text;
    breathingText.classList.toggle('active', isActive);
  } else {
    console.error('[ERROR] Breathing text element not found');
  }
}

// Initialize dot position on page load (before starting)
function initializeDotPosition() {
  const exerciseType = currentExercise;
  const states = animationStates[exerciseType];
  
  if (!states || !states['inhale']) {
    console.error('[ERROR] Animation state not found for', exerciseType, 'inhale');
    return;
  }
  
  const initialState = states['inhale'];
  
  const { startPosition } = initialState;
  
  const dot = document.querySelector('.animation-dot');
  if (dot) {
    dot.style.left = `${startPosition.x}%`;
    dot.style.top = `${startPosition.y}%`;
    console.log('[DEBUG] Set initial dot position for', exerciseType, ':', startPosition);
  } else {
    console.error('[ERROR] Animation dot not found');
  }
} 