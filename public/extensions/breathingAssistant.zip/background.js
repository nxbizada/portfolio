// Logging utility
const log = {
  info: (message) => console.log(`[Background] ${message}`),
  error: (message) => console.error(`[Background Error] ${message}`)
};

// Handle extension installation or update
chrome.runtime.onInstalled.addListener((details) => {
  try {
    if (details.reason === 'install') {
      log.info('Extension installed');
      // You could add first-time setup here
    } else if (details.reason === 'update') {
      log.info('Extension updated');
      // You could add update-specific logic here
    }
  } catch (error) {
    log.error(`Installation error: ${error.message}`);
  }
});

// Handle extension messages
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  try {
    // Handle any background tasks here
    log.info(`Received message: ${message.type}`);
    sendResponse({ success: true });
  } catch (error) {
    log.error(`Message handling error: ${error.message}`);
    sendResponse({ success: false, error: error.message });
  }
  return true; // Keep the message channel open for async response
}); 